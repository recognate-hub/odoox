{
    'name': 'OdooX MCP Connector',
    'version': '1.1',
    'summary': 'Securely connect this Odoo instance to OdooX SaaS.',
    'category': 'Tools',
    'author': 'OdooX',
    'website': 'https://odoox.com',
    'license': 'OPL-1',
    'depends': ['base', 'web'],
    'data': [
        'views/res_config_settings_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
