import requests
import string
import random
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    odoox_link_token = fields.Char(string='OdooX Link Token', config_parameter='odoox.link_token')

    def action_connect_odoox(self):
        token = self.env['ir.config_parameter'].sudo().get_param('odoox.link_token')
        if not token:
            raise UserError(_("Please enter an OdooX Link Token first."))

        # 1. Generate or get API user
        user_env = self.env['res.users'].sudo()
        odoox_user = user_env.search([('login', '=', 'odoox_system_user')], limit=1)
        if not odoox_user:
            odoox_user = user_env.create({
                'name': 'OdooX System User',
                'login': 'odoox_system_user',
                'groups_id': [(6, 0, [self.env.ref('base.group_erp_manager').id])],
            })
        
        # 2. Generate API Key (Odoo 14+ supports auth.api.key or similar, but simplified approach is password for XML-RPC)
        # To ensure it works universally via XML-RPC, we reset the password to a strong secure token.
        secure_password = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        odoox_user.write({'password': secure_password})

        # 3. Gather details
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        db_name = self._cr.dbname

        payload = {
            'link_token': token,
            'odoo_url': base_url,
            'odoo_db': db_name,
            'odoo_username': 'odoox_system_user',
            'odoo_password': secure_password
        }

        # 4. Send to OdooX Backend
        try:
            # Change this to actual prod URL later
            odoox_backend_url = "http://localhost:3000/api/workspace/register"
            response = requests.post(odoox_backend_url, json=payload, timeout=10)
            data = response.json()
            
            if response.status_code == 200 and data.get('status') == 'success':
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Success'),
                        'message': _('Successfully connected to OdooX!'),
                        'type': 'success',
                        'sticky': False,
                    }
                }
            else:
                raise UserError(_("Failed to connect: %s" % data.get('message', 'Unknown error')))
        except Exception as e:
            raise UserError(_("Could not reach OdooX server. Details: %s" % str(e)))
